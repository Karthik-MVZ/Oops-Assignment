package com.zsgs.librasphere.repository.dto;

import java.util.List;

public class StorageStructure {
    private List<Rows> blocks;

    public List<Rows> getBlocks() {
        return blocks;
    }

    public void setBlocks(List<Rows> blocks) {
        this.blocks = blocks;
    }
}