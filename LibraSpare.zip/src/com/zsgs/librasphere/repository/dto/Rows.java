package com.zsgs.librasphere.repository.dto;

import java.util.List;

public class Rows {
    private List<String> books;

    public List<String> getBooks() {
        return books;
    }

    public void setBooks(List<String> books) {
        this.books = books;
    }
}