package com.zsgs.librasphere.utils;

public class Util {

    public String toDateString(Long timeStamp){
        //conversiont logic
        return "DD/MM/YYYY";
    }
}
