package com.zsgs.librasphere.features.base;

public abstract class BaseModel {

}
