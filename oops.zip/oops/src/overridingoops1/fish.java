package overridingoops1;

public class fish extends animal{
    @Override
    public void breathe(){
        System.out.println("Bubbling");
    }
    public void newbreathe(){
        super.breathe();
    }
}
