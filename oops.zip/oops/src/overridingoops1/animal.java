package overridingoops1;

public class animal {
    public void breathe(){
        System.out.println("Breathe");
    }
}
