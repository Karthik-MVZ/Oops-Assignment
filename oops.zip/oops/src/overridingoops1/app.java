package overridingoops1;
//Accessing overridden members
public class app {
    public static void main(String[] args) {
        System.out.println("creating an animal");
        animal a = new animal();

        System.out.println();
        System.out.println("creating lungfish");

        fish lf = new fish();
        lf.breathe();
        lf.newbreathe();
    }
}
