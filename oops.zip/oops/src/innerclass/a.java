package innerclass;

public class a {
    b obj;

    a() {
        obj = new b();
        obj.print();
    }
}
