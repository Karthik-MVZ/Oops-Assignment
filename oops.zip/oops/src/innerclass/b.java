package innerclass;

public class b {
    public void print(){
        System.out.println("Inside B");
    }

}
