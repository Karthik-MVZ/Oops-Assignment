package innerclass;

public class app5 {
    public static void main(String[] args) {
        a obj = new a();
        //obj.print();
    }
}
