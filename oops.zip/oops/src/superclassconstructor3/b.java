package superclassconstructor3;

public class b extends a{
    b(String s){
        System.out.println("B's String constructor");
        System.out.println(s);
    }
}
