package superclassconstructor3;

public class a {
    a(){
        System.out.println("a's constructor");
    }
}
