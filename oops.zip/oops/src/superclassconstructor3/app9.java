package superclassconstructor3;

public class app9 {
    public static void main(String[] args) {


        b obj = new b("Hello from oops");

    }
}
