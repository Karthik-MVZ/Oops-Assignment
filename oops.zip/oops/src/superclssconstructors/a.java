package superclssconstructors;

public class a {
    a(){
        System.out.println("In a's constructor");
    }
}
