package superclssconstructors;

public class b extends a{
    b() {
        System.out.println("in b's constructor");
    }
}