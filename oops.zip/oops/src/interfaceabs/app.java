package interfaceabs;

public class app implements A,B {
    public static void main(String[] args) {
        app obj = new app();
        obj.display1();


    }
}
