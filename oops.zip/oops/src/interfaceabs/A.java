package interfaceabs;

public interface A {
    default void display(){
        System.out.println("from a ");
    }
}
