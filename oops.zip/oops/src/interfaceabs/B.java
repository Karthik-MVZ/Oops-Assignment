package interfaceabs;

public interface B {
    default void display1(){
        System.out.println("from B ");
    }
}
