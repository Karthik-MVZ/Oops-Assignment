package inheritance;

public class app6 {
    public static void main(String[] args) {
        System.out.println("Creating a car...");
        car c = new car();
        c.start();
        c.drive();
    }
}
