package inheritance;

public class car extends vehicle {
    public void drive(){
        System.out.println("Driving......");
    }
}
