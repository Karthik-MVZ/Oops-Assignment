package inheritance;

public class vehicle {
    protected void start(){
        System.out.println("Starting....");
    }
}
