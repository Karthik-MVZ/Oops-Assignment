package minheri;

public class jet extends aircraft{
    public void zoom(){
        System.out.println("Zooming....");
    }
}
