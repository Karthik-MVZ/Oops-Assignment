package minheri;

public class whirlybird extends aircraft{
    public void whirl() {
        System.out.println("Whirling....");
    }
}
