package minheri;

public class aircraft extends vehicle{
    public void whirl(){
        System.out.println("Flying....");
    }
}
