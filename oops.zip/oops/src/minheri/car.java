package minheri;

public class car extends vehicle{
    public void drive(){
        System.out.println("Driving....");
    }
}
