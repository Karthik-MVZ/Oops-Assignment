package minheri;

public class app1 {
    public static void main(String[] args) {
        System.out.println("Creating car....");
        car c = new car();
        c.start();
        c.drive();
        System.out.println();
        System.out.println("creating jet....");
        jet j = new jet();
        j.start();
        j.zoom();
    }
}
