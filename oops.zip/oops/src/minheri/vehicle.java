package minheri;

public class vehicle {
    public void start(){
        System.out.println("Starting....");    }
}
