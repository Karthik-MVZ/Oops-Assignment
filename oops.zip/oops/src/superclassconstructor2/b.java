package superclassconstructor2;

public class b extends a {

    b(String s){
        super(s);
        System.out.println("in b's String constructor");
        System.out.println(s);
    }
}