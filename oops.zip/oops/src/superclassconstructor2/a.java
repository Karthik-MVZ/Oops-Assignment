package superclassconstructor2;
public class a {
    a(){
        System.out.println("In a's constructor");
    }
    a(String s){
        System.out.println("In a's String constructor");
        System.out.println(s);
    }
}
