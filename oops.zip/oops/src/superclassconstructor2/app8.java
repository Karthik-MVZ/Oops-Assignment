package superclassconstructor2;

public class app8 {
    public static void main(String[] args) {
        b obj = new b("Hello oops");
    }
}
