package dynamicmethoddipatch;

public class b extends a{
    public void print(){
        System.out.println("Here is b");
    }
}