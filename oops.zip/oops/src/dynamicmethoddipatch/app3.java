package dynamicmethoddipatch;

public class app3 {
    public static void main(String[] args) {
        a a1 = new a();
        b b1 = new b();
        c c1 = new c();
        d d1 = new d();


    }
}
