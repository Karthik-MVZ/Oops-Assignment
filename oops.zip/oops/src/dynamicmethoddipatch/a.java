package dynamicmethoddipatch;

public class a{
    a(){
        System.out.println("constructor a");
    }

    public void print(){
        System.out.println("Here is a");
    }
}