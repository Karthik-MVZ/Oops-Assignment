package dynamicmethoddipatch;

public class d extends a{
    public void print(){
        System.out.println("Here is d");
    }
}
