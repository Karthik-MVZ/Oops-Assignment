package dynamicmethoddipatch;

public class c extends a{
    public void print(){
        System.out.println("Here is c");
    }
}