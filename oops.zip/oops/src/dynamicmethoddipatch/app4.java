package dynamicmethoddipatch;

public class app4 {
    public static void main(String[] args) {
        a a1 = new a();
        b b1 = new b();
        c c1 = new c();
        d d1 = new d();
        a aref;
        aref = a1;
        aref.print();
        aref = b1;
        aref.print();
        a1.print();
        aref = c1;
        aref.print();
        aref = d1;
        aref.print();

    }
}
