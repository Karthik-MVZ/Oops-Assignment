package overidingoops2;

import minheri.aircraft;

public class jet extends whirlybird {
    public void zoom(){
        System.out.println("Zooming....");
    }
}
