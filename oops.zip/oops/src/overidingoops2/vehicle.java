package overidingoops2;

public class vehicle {
    public void start(){
        System.out.println("Starting....");    }
}
