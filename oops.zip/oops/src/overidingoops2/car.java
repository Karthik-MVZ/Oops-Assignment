package overidingoops2;

import minheri.vehicle;

public class car extends vehicle {
    public void drive(){
        System.out.println("Driving....");
    }
}
