package overidingoops2;

import minheri.vehicle;

public class aircraft extends vehicle {
    public void whirl(){
        System.out.println("Flying....");
    }
}
