package overidingoops2;

import minheri.aircraft;

public class whirlybird extends aircraft {
    public void whirl() {
        System.out.println("Whirling....");
    }
}
