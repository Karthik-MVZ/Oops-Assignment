package overidingoops2;

import minheri.jet;
import minheri.vehicle;

public class app2 {
    public static void main(String[] args) {
        System.out.println("Creating car....");
        car c = new car();
        c.start();
        c.drive();
        System.out.println();
        System.out.println("creating jet....");
        vehicle j = new jet();
        j.start();
       // j.zoom();


    }
}