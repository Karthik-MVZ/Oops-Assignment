package encapsulate;

public class son extends father{
        private int bankbalance = 30000;
        int house = 1;

   public void display(){
       System.out.println("son");
   }
    public static void main(String[] args) {
        //father obj = new father();
        //son obj = new son();
        //son obj =  new father();
        father obj = new son();
        System.out.println(obj.house);
        //System.out.println(obj.house);

        obj.display();
       // System.out.println(obj.getBankBalance());
        //System.out.println(obj.Bankbalance());

    }

}
