package encapsulate;

public class daughter {
}
