package encapsulate;

public class father {
    private int bankbalance=20000;

    public int getBankbalance() {
        return bankbalance;
    }

    int house = 2;




    public void display(){
        System.out.println("father");
    }
}
